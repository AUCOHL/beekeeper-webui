#pragma once
//https://github.com/Skyus/Archive/tree/master/AXI4Lite

struct AXI4Lite {
    enum BusType {
        AWVALID = 0,
        AWADDR,
        AWPROT,
        AWREADY,
        WVALID,
        WDATA,
        WSTRB,
        WREADY,
        BREADY,
        BVALID,
        BRESP,
        ARVALID,
        ARADDR,
        ARPROT,
        ARREADY,
        RREADY,
        RVALID,
        RDATA,
        RRESP
    };

    enum Response {
        OKAY = 0, //Okay
        EXOKAY, //Not supported in AXI4-lite
        SLVERR, //Slave error
        DECERR //Decoded error
    };

    static const int busCount = 19;
    static const bool masterControlled[];
};

#include "AXI4Lite.h"

const bool AXI4Lite::masterControlled[] = {
    true, true, true, false, true, true, true, false, true, false, false, true, true, true, false, true, false, false, false
};
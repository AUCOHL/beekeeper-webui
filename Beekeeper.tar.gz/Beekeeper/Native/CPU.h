#pragma once

//CPP STL
#include <string>
#include <map>
#include <functional>
#include <queue>

//Project Headers
#include "Common.h"
#include "Breakpoint.h"
#include "Event.h"
#include "IO.h"

//Abstract CPU
class CPU {
public:
    enum RunMode {
        STEP_FALSE = 0,
        STEP_LINE,
        STEP_BP,
        STEP_INST
    };

    enum Status {
        STATUS_IDLE = 0,
        STATUS_RUNNING,
        STATUS_EBREAK
    };

    //Beekeeper
    //These aren't to be actually implemented for the abstract class, just for every Core
    static bool registerCore();
    static bool registered;

    uint32 buses[Constants::maxBuses];
    uint64 cycleCounter;
    std::priority_queue<Event> cpuBusEvents;
    std::priority_queue<Event> memoryBusEvents;
    Status status;
    RunMode runMode;

    size_t busCount;
    bool *masterControlled;

    //Methods
    virtual bool initialize() = 0;
    virtual void update() = 0;
    virtual void exit() = 0;

    // virtual std::vector<uint8> memoryRead(uint start, size_t count, bool& successful) = 0;
    // virtual bool memoryWrite(uint start, uint8 byte) = 0;

    static std::map< std::string, std::function<CPU*(JSON*)> > database;
    static CPU* pliCore;
};

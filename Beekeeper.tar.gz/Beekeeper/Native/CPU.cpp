#include "CPU.h"


CPU* CPU::pliCore = NULL;
auto CPU::database = std::map < std::string, std::function<CPU*(JSON*)> >();

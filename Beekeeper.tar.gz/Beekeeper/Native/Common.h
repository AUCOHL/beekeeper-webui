#pragma once

#ifdef __cplusplus
#include <cstdint>
#else
#include <stdint.h>
#include <stdbool.h>
#endif

#define int8 int8_t
#define uint8 uint8_t
#define int16 int16_t
#define uint16 uint16_t
#define int32 int32_t
#define uint32 uint32_t
#define int64 int64_t
#define uint64 int64_t

#define BEEKEEPER_MAJOR_VERSION 0
#define BEEKEEPER_MINOR_VERSION 7
#define BEEKEEPER_PATCH_VERSION 0

#define forever for(;;)

enum Strobe {
    RAMSIZE_BYTE = 0b0001,
    RAMSIZE_HALF = 0b0011,
    RAMSIZE_WORD = 0b1111
};

class Constants {
public:
    static const int maxBuses = 64;
};

#ifdef _DEBUG
    #define onDebug(x) x
#else
    #define onDebug(x) ;
#endif

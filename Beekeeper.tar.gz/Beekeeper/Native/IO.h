#pragma once

//CPP STL
#include <string>

//Libraries
#include "Libraries/JSON.h"

using JSON = nlohmann::json;

class CPU;

class IO {
public:
    /*
    Error structure:
    {
        "errorCode": Int, //BSD Error Number (See sysexits.h on macOS, a *BSD Unix and most Linux-based OSes.)
        "culprit": String, //The data causing the problem, i.e. file where I/O failed or the like
        "runtime":  Bool, //Is the error a runtime error or a Beekeeper error,
        "dataDump": JSON? { //Only if runtime
            "address": Int, //The address of the instruction that triggered said error
            "registers": Array [ //Register Dump
                0x00000000, ... , 0xfffffffb            ]
        }
    }
    */
    static void error(JSON message);
    
    /*
    Break structure:
    {
        "address": Int, //Address of current instruction
        "file": String, //File for this breakpoint,
        "line": Int, //Line for this breakpoint,
        "registers": Array [
            0x00000000, ..., 0xfffffffb
        ]
    }
    */
    static int environmentBreak(uint address, std::string file, int line, int registerCount, uint32 registerFile[], CPU &sender); 

    static JSON debugConfiguration();
    static JSON soc();
};
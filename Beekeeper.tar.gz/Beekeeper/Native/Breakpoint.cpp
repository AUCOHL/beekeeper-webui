//CPP STL
#include <fstream>

//Project Headers
#include "Breakpoint.h"
#include "IO.h"

Breakpoint::Breakpoint() {
    address = 0x00000000; file = "/dev/null"; line = 0; 
}

std::map<uint32, Breakpoint> Breakpoint::parseFile(std::string path) {
    std::ifstream file;
    file.open(path);
    if (file.fail()) {
        onDebug(IO::error({{"errorCode", 66}, {"culprit", path}, {"runtime", false}}));
        return std::map<uint32, Breakpoint>();
    }

    std::map<uint32, Breakpoint> breakpoints;

    auto empty = false;
    
    forever {
        uint32 address, line;
        std::string target, garbage;
        file >> std::hex >> address;
        getline(file, garbage);
        if (file.eof()) {
            break;
        }
        getline(file, target);
        file >> std::dec >> line;
        getline(file, garbage);        
        breakpoints[address] = Breakpoint(address, target, line);
    }

    return breakpoints;
}

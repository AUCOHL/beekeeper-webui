#pragma once

//Project Headers
#include "Common.h"

//Bus Event System
struct Event {
    int bus;
    uint64 value;
    uint32 cycle;

    Event(int _bus, uint32 _value, uint32 _cycle): bus(_bus), value(_value), cycle(_cycle) {}
};
bool operator<(const Event& left, const Event& right);
//CPP STL
#include <fstream>
#include <sstream>
#include <iostream>
#include <iomanip>

//Project Headers
#include "Common.h"
#include "Libraries/Utilities.h"
#include "IO.h"

#include "Cores/MultiBee.h"

MultiBee::MultiBee(JSON *ramObject) {
    busCount = AXI4Lite::busCount;
    masterControlled = (bool*)AXI4Lite::masterControlled;
    if (ramObject) {    
        ramStart = (*ramObject)["start"];
        ramSize = (*ramObject)["length"];
        ram = new uint8[ramSize];

        onDebug(std::cout << "Memory initialized: " << ramSize << " bytes allocated." << std::endl);
    } else {
        ramStart = 0;
        ramSize = 0;
    }
}

bool MultiBee::registerCore() {
    CPU::database["MultiBee"] = [](JSON* ramObject) -> CPU* {
        return (CPU*)(new MultiBee(ramObject));
    };
    
    return true;
}
bool MultiBee::registered = MultiBee::registerCore();

bool MultiBee::initialize() {
    auto debugConfiguration = IO::debugConfiguration();

    programPath = debugConfiguration["programPath"];

    //Hardware Setup
    programCounter = 0;

    //Loading Program
    std::ifstream programFile(programPath.c_str(), std::ios::ate | std::ios::in | std::ios::binary);
    if (programFile.fail()) {
        IO::error({{"errorCode", 66}, {"culprit", programPath}, {"runtime", false}});
        ::exit(66);
    }

    size_t fileSize = (size_t)programFile.tellg();
    std::vector<char> programBuffer(fileSize);
    programFile.seekg(0);
    programFile.read(programBuffer.data(), fileSize);
    numLines = fileSize / 4;
    for (uint address = 0; address < fileSize; address++) {
        uint8 byte = (uint8)programBuffer[address];
        ram[address] = byte;
    }
    programFile.close();
    CreateDumpDir();

    //Activating Breakpoints
    breakpoints = Breakpoint::parseFile(programPath + "_dump/lines.txt");

    runMode = STEP_BP;
    if (debugConfiguration["runMode"] == "stepByStep") {
        if (breakpoints.size() == 0) {
            runMode = STEP_INST;
        } else {
            runMode = STEP_LINE;
        }
    } else if (debugConfiguration["runMode"] == "fastForward") {
        runMode = STEP_FALSE;
    }
    
    // Running
    status = STATUS_RUNNING;

    startTime = std::chrono::high_resolution_clock::now();

    cycleCounter = -1;
    instructionCounter = 0;
    waitOnRead = -1;
    waitOnWrite = -1;

    // Suppress RAM errors by forcing the address to initialize at 0
    RAMaddr = 0;
    
    // Zero out Zero register.    
    registerFile[0] = 0;

    // Set SP to RAMSIZE   
    registerFile[2] = ramSize;

    cpuBusEvents.push(Event(AXI4Lite::RREADY, 0b1, 0));

    return true;
}

uint32 MultiBee::MemoryRead(uint32 RAMaddr, bool RAMsigned, uint8 RAMSize) {
    uint32 RAMout;

    std::string size;
    switch (RAMSize) {
        case RAMSIZE_BYTE:
            RAMout = (uint32)((uint8)ram[RAMaddr]);
            if (RAMsigned) {
                bool bitSign = (int8_t)RAMout >= 0;
                RAMout |= ((0xffffff00) * !bitSign);
            }
            break;
        case RAMSIZE_HALF:
            RAMout |= (ram[RAMaddr+1] <<  8) & (0x0000ff00);
            if (RAMsigned) {
                bool bitSign = (int8_t)RAMout >= 0;
                RAMout |= ((0xffff0000) * !bitSign);
            }
            break;
        case RAMSIZE_WORD:
            RAMout = ram[RAMaddr+3];
            RAMout = (RAMout << 8) + ram[RAMaddr+2];
            RAMout = (RAMout << 8) + ram[RAMaddr+1];
            RAMout = (RAMout << 8) + ram[RAMaddr];
            break;
    }

    return RAMout;
}

void MultiBee::memoryRead(uint32 address, Strobe strobe, int targetRegister, bool signedRead) {
     
    cpuBusEvents.push(Event(AXI4Lite::ARVALID, 1, cycleCounter + 3));
    cpuBusEvents.push(Event(AXI4Lite::ARADDR, address, cycleCounter + 3));
    cpuBusEvents.push(Event(AXI4Lite::ARPROT, 0b001, cycleCounter + 3));

    //Check if address is in INSTANTRAM BFM
    if (address >= ramStart && address < (ramStart + ramSize)) {        
        auto data = MemoryRead(address, false, RAMSIZE_WORD);
        cpuBusEvents.push(Event(AXI4Lite::ARVALID, 0, cycleCounter + 4));
        memoryBusEvents.push(Event(AXI4Lite::ARREADY, 0b1, cycleCounter + 3));
    
        memoryBusEvents.push(Event(AXI4Lite::RVALID, 0b1, cycleCounter + 3));
        memoryBusEvents.push(Event(AXI4Lite::RRESP, AXI4Lite::OKAY, cycleCounter + 3));
        memoryBusEvents.push(Event(AXI4Lite::RDATA, data, cycleCounter + 3));
        memoryBusEvents.push(Event(AXI4Lite::RVALID, 0b0, cycleCounter + 4));
    
        registerFile[targetRegister] = MemoryRead(address, signedRead, RAMSIZE_BYTE);
    } else {
        waitOnRead = cycleCounter + 3;
        destinationRegister = targetRegister;
    }
}

void MultiBee::resumeRead() {
    if (buses[AXI4Lite::RVALID]) {
        registerFile[destinationRegister] = buses[AXI4Lite::RDATA];
        cpuBusEvents.push(Event(AXI4Lite::ARVALID, 0, cycleCounter + 1));
        if (currentWait == 0) {
            currentWait++;
        }
        //TODO: Something about OKAY or not OKAY
    } else {
        //Keep waiting until data is available
        currentWait++;
        waitOnRead = cycleCounter + 1;
    }
}

void MultiBee::MemoryWrite(uint32 RAMin, uint32 RAMaddr, uint8 RAMSize) {
    std::string size = "";
    switch (RAMSize) {
        case RAMSIZE_BYTE:
            ram[RAMaddr] = (unsigned char) RAMin;
            break;
        case RAMSIZE_HALF:
            ram[RAMaddr]   = (unsigned char) RAMin;
            ram[RAMaddr+1] = (unsigned char) (RAMin >>= 8);
            break;
        case RAMSIZE_WORD:
            ram[RAMaddr]   = (unsigned char) (RAMin);
            ram[RAMaddr+1] = (unsigned char) (RAMin >>= 8);
            ram[RAMaddr+2] = (unsigned char) (RAMin >>= 8);
            ram[RAMaddr+3] = (unsigned char) (RAMin >>= 8);
            break;
    }
}

void MultiBee::memoryWrite(uint32 address, Strobe strobe, int targetRegister) {

    auto data = registerFile[targetRegister];

    cpuBusEvents.push(Event(AXI4Lite::AWVALID, 1, cycleCounter + 3));
    cpuBusEvents.push(Event(AXI4Lite::AWADDR, address, cycleCounter + 3));
    cpuBusEvents.push(Event(AXI4Lite::AWPROT, 0b001, cycleCounter+ 3));

    cpuBusEvents.push(Event(AXI4Lite::WVALID, 1, cycleCounter + 3));
    cpuBusEvents.push(Event(AXI4Lite::WDATA, data, cycleCounter + 3));
    cpuBusEvents.push(Event(AXI4Lite::WSTRB, strobe, cycleCounter + 3));
    
    cpuBusEvents.push(Event(AXI4Lite::BREADY, 0b1, cycleCounter + 4));

    //Check if address is in INSTANTRAM BFM
    if (address >= ramStart && address < (ramStart + ramSize)) {
        cpuBusEvents.push(Event(AXI4Lite::AWVALID, 0, cycleCounter + 4));
        memoryBusEvents.push(Event(AXI4Lite::AWREADY, 0b1, cycleCounter + 3));

        cpuBusEvents.push(Event(AXI4Lite::WVALID, 0, cycleCounter + 4));
        memoryBusEvents.push(Event(AXI4Lite::WREADY, 0b1, cycleCounter + 3));

        memoryBusEvents.push(Event(AXI4Lite::BRESP, AXI4Lite::OKAY, cycleCounter + 4));
        memoryBusEvents.push(Event(AXI4Lite::BVALID, 1, cycleCounter + 4));
        cpuBusEvents.push(Event(AXI4Lite::BREADY, 0b0, cycleCounter + 5));
        memoryBusEvents.push(Event(AXI4Lite::BVALID, 0, cycleCounter + 5));
        
        MemoryWrite(data, address, strobe);
    } else {
        waitOnWrite = cycleCounter + 3;
        sourceRegister = targetRegister;
    }
}

void MultiBee::resumeWrite() {
    if (buses[AXI4Lite::BVALID]) {
        cpuBusEvents.push(Event(AXI4Lite::AWVALID, 0, cycleCounter + 1));
        cpuBusEvents.push(Event(AXI4Lite::WVALID, 0, cycleCounter + 1));
        cpuBusEvents.push(Event(AXI4Lite::BREADY, 0b0, cycleCounter + 1));
        if (currentWait == 0) {
            currentWait++;
        }        
    } else {
        //Keep waiting until data is available
        currentWait++;
        waitOnWrite = cycleCounter + 1;
    }
}

void MultiBee::ControlPath() {
    // Get Instruction
    uint32 instruction = catBytes(&ram[programCounter % ramSize]);
    uint8 bits[32];

    uint32 mask = 1 << 31;
    for (uint32 i = 0; i < 32; i++) {
        bits[31-i] = ((instruction & mask) != 0);
        mask = mask >> 1;
    }
    
    cpuBusEvents.push(Event(AXI4Lite::ARVALID, 0b1, cycleCounter));
    cpuBusEvents.push(Event(AXI4Lite::ARVALID, 0b0, cycleCounter + 1));    
    cpuBusEvents.push(Event(AXI4Lite::ARADDR, programCounter, cycleCounter));
    cpuBusEvents.push(Event(AXI4Lite::ARPROT, 0b101, cycleCounter));
    memoryBusEvents.push(Event(AXI4Lite::ARREADY, 0b1, cycleCounter));

    memoryBusEvents.push(Event(AXI4Lite::RVALID, 0b1, cycleCounter));
    memoryBusEvents.push(Event(AXI4Lite::RVALID, 0b0, cycleCounter + 1));
    memoryBusEvents.push(Event(AXI4Lite::RRESP, AXI4Lite::OKAY, cycleCounter));
    memoryBusEvents.push(Event(AXI4Lite::RDATA, instruction, cycleCounter));
    cpuBusEvents.push(Event(AXI4Lite::RREADY, 0b1, cycleCounter));

    // Decode Instruction
    if (printDebug)
        DecodeInstructionPrint(bits);
    else
        DecodeInstruction(bits);
}

std::string MultiBee::DecodeRegister(int reg) {
    switch(reg) {
        case 0:
            return "zero"; 
        case 1:
            return "ra";
        case 2:
            return "sp";
        case 3:
            return "gp";
        case 4:
            return "tp";
        case 5:
            return "t0";
        case 6:
            return "t1";
        case 7:
            return "t2"; 
        case 8:
            return "s0";
        case 9:
            return "s1"; 
        case 10:
        case 11:
        case 12:
        case 13:
        case 14:
        case 15:
        case 16:
        case 17:
            return "a" + std::to_string(reg-10); 
        case 18:
        case 19:
        case 20:
        case 21:
        case 22:
        case 23:
        case 24:
        case 25:
        case 26:
        case 27:
            return "s" + std::to_string(reg-16);
        case 28:
            return "t3";
        case 29:
            return "t4";
        case 30:
            return "t5";
        case 31:
            return "t6";
    }
    return "";
}

void MultiBee::update() {
    //Bus Events
    if (cycleCounter == waitOnRead) {
        resumeRead();
    }
    if (cycleCounter == waitOnWrite) {
        resumeWrite();
    }

    if (runMode && currentWait == 0) {
        if (
            (runMode == STEP_INST) ||
            (runMode == STEP_LINE && breakpoints.find(programCounter) != breakpoints.end()) ||
            (runMode == STEP_BP && breakpoints.find(programCounter) != breakpoints.end() && breakpoints[programCounter].active)
        ) {
            auto properStop = (runMode == STEP_LINE || runMode == STEP_BP);
            runMode = (RunMode)IO::environmentBreak(
                programCounter,
                properStop? breakpoints[programCounter].file: "",
                properStop? breakpoints[programCounter].line: -1,
                32,
                registerFile,
                *this
            );
        }
    }
    
    // Actual cycle
    if (status == STATUS_RUNNING) {
        if (!currentWait) {
            ControlPath();
            instructionCounter += 1; //Just for statistic purposes (calculate execution speed)
        } else {
            currentWait -= 1;
        }
    }
    
    // Leave this last to clean up register zero
    registerFile[0] = 0;
}

void MultiBee::CreateDumpDir() {
    struct stat st = {0};
    std::string outpath = programPath + "_dump/";
    if (stat(outpath.c_str(), &st) == -1)
        mkdir(outpath.c_str(), 0755);
}

void MultiBee::DumpRegFile() {
    std::ofstream out;
    std::string outpath =  programPath + "_dump/registers.txt";
    out.open(outpath.c_str());
    if (out.fail()) {
        printf("Error: Failed to dump registers for test: %s\n", outpath.c_str());
        return;
    }

    for (size_t i = 0; i < 32; i++) {
        out << "Register " << std::dec << i << ": " << (int)registerFile[i] << "\n";
    }  

    out.close();
}

void MultiBee::DumpRAM() {
    std::ofstream out;
    std::string outpath =  programPath + "_dump/ram.txt";
    out.open(outpath.c_str());
    if (out.fail()) {
        printf("Error: Failed to dump RAM for test: %s\n", outpath.c_str());
        return;
    }

    for (size_t i=0; i < ramSize/4; i++) {
        uint32 num = ram[i*4];
        num |= (ram[i*4+1] <<  8) & (0x0000ff00);
        num |= (ram[i*4+2] << 16) & (0x00ff0000);
        num |= (ram[i*4+3] << 24) & (0xff000000);
        out << "0x" << std::hex << std::setfill('0') << std::setw(8) << num << "\n";
    }
    out.close();
}

void MultiBee::DumpLog() {
    std::ofstream out;
    std::string outpath =  programPath + "_dump/log.txt";
    out.open(outpath.c_str());
    if (out.fail()) {
        printf("Error: Failed to dump instruction log for test: %s.\n", outpath.c_str());
        return;
    }
    
    out << logBuffer;

    out.close();
}

void MultiBee::AddToLog(std::string str) {
    logBuffer += str;
}

void MultiBee::exit() {
	std::chrono::time_point<std::chrono::high_resolution_clock> currentTime = std::chrono::high_resolution_clock::now();
    long long elapsed = std::chrono::duration_cast<std::chrono::nanoseconds>(currentTime - startTime).count();
    double ips = instructionCounter * 1000000000.0 / std::chrono::duration_cast<std::chrono::nanoseconds>(currentTime - startTime).count();
    std::cout << "Finished in " << elapsed <<  " nanoseconds (" << std::setiosflags (std::ios::fixed) << std::setprecision(2) << ips << " instructions per second).\n";
    status = STATUS_IDLE;
    breakpoints.clear();
    DumpRegFile();
    DumpRAM();
    if (printDebug)
        DumpLog();
    vpi_finish();
}

std::string MultiBee::PrintProgram() {
    std::string buffer = "";
    for (size_t i = 0; i < numLines; i++) {
        buffer += PrintDecodeLine(i);
    }

    programCounter = 0; // Reset program counter just in case it did anything.
    return buffer;
}

std::string MultiBee::PrintDecodeLine(uint32 line) {
    uint32 instruction = catBytes(&ram[line*4 % ramSize]);
    uint8 bits[32];

    uint32 mask = 1 << 31;
    for (uint32 i = 0; i < 32; i++) {
        bits[31-i] = ((instruction & mask) != 0);
        mask = mask >> 1;
    }
    
    return "NOP";
}
#include "MultiBeeDecodeBase.tcc"
#define PrintDecode
#include "MultiBeeDecodeBase.tcc"

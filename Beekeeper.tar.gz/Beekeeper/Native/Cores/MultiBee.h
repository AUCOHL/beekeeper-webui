#pragma once

//CPP STL
#include <string>
#include <vector>
#include <queue>
#include <map>
#include <unordered_map>
#include <chrono>

//POSIX
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>

//Project Headers
#include "Common.h"
#include "CPU.h"
#include "Architectures/RV32I.h"
#include "Buses/AXI4Lite.h"

//MultiBee
class MultiBee: public CPU {
    uint32 MemoryRead(uint32 RAMaddr, bool RAMsigned, uint8 RAMSize);
    void MemoryWrite(uint32 RAMin, uint32 RAMaddr, uint8 RAMSize);
    
    //========== CPU INSTRUCTION PARAMS ==========//
    // Register File
    uint32  RegAaddress;
    uint32  RegBaddress;
    uint32  RegDaddress;
    bool    RegWrite;

    // Immediates
    int32_t immediateValue;
    bool    useImmediate;

    // RAM
    uint8   RAMSize;
    uint32  RAMin;
    uint32  RAMaddr;
    uint8   RAMsize;
    bool    RAMwrite;
    bool    RAMtransfer;
    bool    RAMsigned;
    //======== END CPU INSTRUCTION PARAMS ========//

    //Atomics
    uint32 programCounter;
    uint32 currentWait;
    uint32 registerFile[32];
    
    //RAM
    uint8 *ram;
    size_t ramStart;
    size_t ramSize;
    uint32 numLines;    

    //Debugging Features
    std::map<uint32, Breakpoint> breakpoints;       
    std::chrono::time_point<std::chrono::high_resolution_clock> startTime;
    uint32 instructionCounter; 
    bool paused, printDebug;
    std::string programPath = "\0";

    //Hack to make bus events work until we rewrite the simulation code/get veronia's pipeline
    uint64 waitOnRead;
    int destinationRegister;
    void memoryRead(uint32 address, Strobe strobe, int targetRegister, bool signedRead = true);
    void resumeRead();

    uint64 waitOnWrite;
    int sourceRegister;
    void memoryWrite(uint32 address, Strobe strobe, int targetRegister);
    void resumeWrite();
    
    //Methods
    void ControlPath();
    void DecodeInstruction(uint8 bits[]);
    void DecodeInstructionPrint(uint8 bits[]);
    std::string DecodeRegister(int n);

    std::string PrintProgram();
    std::string PrintDecodeLine(uint32 line);

    std::string logBuffer;
    void AddToLog(std::string);

    void CreateDumpDir();
    void DumpRegFile();
    void DumpRAM();
    void DumpLog();

public:    
    static bool registerCore();
    static bool registered;

    bool initialize();
    void update();
    void exit();

    MultiBee(JSON* ramObject);

    static CPU* pliCore;
};

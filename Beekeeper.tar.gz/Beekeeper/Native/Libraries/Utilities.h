#pragma once
//CPP STL
#include <iostream>

//Project Headers
#include "Common.h"

bool CompareBits(uint8 A[], uint8 B[], uint32 offset, uint32 size);
void MoveBits(uint8 from[], uint8 to[], uint8 offset, uint8 size);
void MoveBits(uint8 from[], uint8 to[], uint8 offset, uint8 offset2, uint8 size);
void PrintBits(uint8 bits[], uint8 size);
int32 BitsToInt(uint8 bits[], uint8 size);
uint32 BitsToUInt(uint8 bits[], uint8 size);
void PrintBitsFromNumber(int32_t num);
uint32 catBytes(uint8 bytes[]); //🐱
void vpi_finish();
#include "Utilities.h"

bool CompareBits(uint8 A[], uint8 B[], uint32 offset, uint32 size) {
    for (uint32 i = 0; i < size; i++) {
        if (A[offset + i] != B[i])
            return false;
    }

    return true;
}

void MoveBits(uint8 from[], uint8 to[], uint8 offset, uint8 size) {
    for (uint8 i = 0; i < size; i++) {
        to[i] = from[offset + i];
    }
}

void MoveBits(uint8 from[], uint8 to[], uint8 offset, uint8 offset2, uint8 size) {
    for (uint8 i = 0; i < size; i++) {
        to[offset2 + i] = from[offset + i];
    }
}

void PrintBits(uint8 bits[], uint8 size) {
    for (uint8 i = 0; i < size; i++) {
        std::cout << (int)bits[i];
        if (i % 8 == 0)
            std::cout << " ";
    }

    std::cout << "\n";
}

int32_t BitsToInt(uint8 bits[], uint8 size) {
    int32_t value = 0;
    for (uint8 i=0; i < size - 1; i++) {
        value |= (1 << (i)) * bits[i];
    }

    for (uint8 i=size-1; i < 32; i++) {
        value |= (1 << i) * bits[size-1];
    }

    return value;
}

uint32 BitsToUInt(uint8 bits[], uint8 size) {
    uint32 value = 0;
    for (uint8 i=0; i < size; i++) {
        value |= (1 << (i)) * bits[i];
    }

    return value;
}

void PrintBitsFromNumber(int32_t num) {
    uint32 mask = 1 << 31;
    for (uint32 i = 0; i < 32; i++) {
        std::cout << ((num & mask) != 0);
        mask = mask >> 1;
        if (i%8 == 0)
            std::cout << " ";
    }

    std::cout << "\n";
}

uint32 catBytes(uint8 bytes[]) {
    uint32 storage = 0;

    for (int i = 0; i < 4; i++) {
        storage = storage | (bytes[i] << (8 * i));
    }

    return storage;
}

uint32 catBytes(uint8 bytes[], int count) {
    uint32 storage = 0;

    for (int i = 0; i < count; i++) {
        storage = storage | (bytes[i] << (8 * i));
    }
    
    return storage;
}
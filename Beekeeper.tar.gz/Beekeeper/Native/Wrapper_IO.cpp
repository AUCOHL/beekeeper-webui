#ifdef _bk_cli

//CPP STL
#include <iostream>
#include <fstream>

//Project Headers
#include "Libraries/Utilities.h"

#include "CPU.h"

#include "IO.h"

void IO::error(JSON message) {
    onDebug(std::cerr << message.dump(4) << std::endl;)
}

JSON IO::debugConfiguration() {
    //Input
    bool input = true;
    std::string buffer;

    //Data
    auto environmentProgram = std::getenv("BEEKEEPER_PROGRAM");
    onDebug(std::cerr << "Environment Program: " << environmentProgram << std::endl);
    std::string programPath = environmentProgram? environmentProgram: "None";
    std::string runMode = "normal";

    std::cout << "Beekeeper - " << BEEKEEPER_MAJOR_VERSION << "." << BEEKEEPER_MINOR_VERSION;

    if (BEEKEEPER_PATCH_VERSION < 0) {
        std::cout << "-dev" << std::endl;
    } else {
        std::cout << "." << BEEKEEPER_PATCH_VERSION << std::endl;
    }

    std::cout << "Type 'help' for help.\n\tTargetting: " << programPath << "\n";
    while (input) {
        std::cout << "> ";
        std::cin >> buffer;
        if (std::cin.eof())
        {
            std::cout << std::endl;
            vpi_finish();
            exit(65);
        }

        if (buffer == "help") {
            std::cout << "'r': Run. 'f': Fast forward (ignore breakpoints.) 's': Run program step by step. 'Finish': exit." << std::endl;
        } else if (buffer == "r") {
            std::cout << "Running normally..." << std::endl;
            break;
        } else if (buffer == "f") {
            runMode = "fastForward";
            std::cout << "Running ignoring breakpoints..." << std::endl;
            break;
        } else if (buffer == "s") {
            runMode = "stepByStep";
            std::cout << "Running step by step...";
            break;
        } else if (buffer == "finish") {
            vpi_finish();
            exit(0);
        } else {
            programPath = buffer;
            std::cout << "Program path set to '" << buffer << "'." << std::endl;
        }
    }

    return {{"programPath", programPath}, {"runMode", runMode}};
}

JSON IO::soc() {
    std::ifstream memoryMapStr;
    memoryMapStr.open("soc.json");
    if (memoryMapStr.fail()) {
        std::cerr << "Did not find the file 'soc.json' in this directory." << std::endl;
        exit(66);
    }
    return JSON::parse(memoryMapStr)[0];
}

int IO::environmentBreak(uint address, std::string file, int line, int registerCount, uint32 registerFile[], CPU& sender) {
    forever {
        fflush(NULL);

        std::string buffer;
        std::cout << "[";
        if (line != -1) {
            std::cout << file << ":" << line << " ";
        }
        std::cout << "0x" << std::hex << std::setfill('0') << std::setw(8) << address << "]" << std::endl << std::setfill(' ') << std::dec;
        std::cout << "(beekeeper) ";
        std::cin >> buffer;
        if (std::cin.eof()) {
            std::cout << std::endl;
            vpi_finish();
            ::exit(65);
        }
        if (buffer == "help") {
            std::cout << "'s' to step one instruction forward. 'f' to execute the rest of the program uninterrupted. 'finish' to finish." << std::endl;
        } else if (buffer == "s") {
            return sender.runMode;
        } else if (buffer == "f") {
            return CPU::STEP_FALSE;
        } else if (buffer == "finish") {
            vpi_finish();
            exit(0);
        } else {
            std::cout << "Invalid input. (Write 'help' for instructions.)" << std::endl;
        }
    }
}

#include "nbind/nbind.h"

NBIND_CLASS(IO) {
  method(environmentBreak);
  method(debugConfiguration);
  method(error);
  method(soc);
}
#endif

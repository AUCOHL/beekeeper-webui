#pragma once

//CPP STL
#include <string>
#include <map>

//Project Headers
#include "Common.h"

//Breakpoint
struct Breakpoint {
    uint32 address;
    std::string file;
    uint32 line;

    uint32 store;
    bool active = false;

    Breakpoint();
    Breakpoint(uint32 _address, std::string _file, uint32 _line): address(_address), file(_file), line(_line) {}

    static std::map<uint32, Breakpoint> parseFile(std::string path);    
};
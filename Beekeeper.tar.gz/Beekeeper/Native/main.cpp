//CPP STL
#include <iostream>

//POSIX
#include <cstdlib>

//Project Headers
#include "CPU.h"
#include "IO.h"

extern "C" {
    #include <iverilog/vpi_user.h>
}

void vpi_finish() {
    vpi_control(vpiFinish, 0);
}

static int initialize_compiletf(char* user_data) {
    
    // auto handle = vpi_handle(vpiSysTfCall, NULL);
    // if (handle == NULL) {
    //     printf("Fatal Error: Failed to obtain handle. The simulation will abort.\n");
    //     vpi_finish();
    //     return 0;
    // }
    
    // auto iterator = vpi_iterate(vpiArgument, handle);
    // if (iterator == NULL) {
    //     printf("Error: No arguments.\n");
    //     vpi_finish();
    //     return 0;
    // }
    
    // int i = 0;
    // auto argument = vpi_scan(iterator);
    
    // while (argument) {
    //     i += 1;
        
    //     auto type = vpi_get(vpiType, argument);
        
    //     if (type != vpiParameter) {
    //         printf("Error: Argument %i: invalid argument.\n", i);
    //         vpi_finish();
    //         return 0;
    //     }
    //     argument = vpi_scan(iterator);
    // }
    
    // if (i != 1) {
    //     printf("Error: Invalid argument count. (%i/1)\n", i);
    //     vpi_finish();
    // }
    
    return 0;
}

static int initialize_calltf(char* user_data) {
    
    // auto handle = vpi_handle(vpiSysTfCall, NULL);
    // auto iterator = vpi_iterate(vpiArgument, handle);
    // auto argument = vpi_scan(iterator);
    
    // t_vpi_value value;
    // value.format = vpiIntVal;
    
    // vpi_get_value(argument, &value);
    
    // CPU::pliCore->ramSize = value.value.integer;
    // CPU::pliCore->ram = new uint8[CPU::pliCore->ramSize];
    
    // std::cout << "Memory initialized: " << CPU::pliCore->ramSize << " bytes allocated." << std::endl;
    
    if (!CPU::pliCore->initialize()) {
        vpi_finish();
        return 1;
    }    
    return 0;
}

int32_t update_compiletf(char* user_data) {
    auto handle = vpi_handle(vpiSysTfCall, NULL);
    if (handle == NULL) {
        printf("Fatal Error: Failed to obtain handle. The simulation will abort.\n");
        vpi_finish();
        return 0;
    }

    auto iterator = vpi_iterate(vpiArgument, handle);
    if (iterator == NULL) {
        printf("Error: No arguments.\n");
        vpi_finish();
        return 0;
    }

    int i = 0;
    auto argument = vpi_scan(iterator);

    while (argument) {
        i += 1;

        auto type = vpi_get(vpiType, argument);

        if (type != vpiNet && type != vpiReg) {
            printf("Error: Argument %i: invalid argument.\n", i);
            vpi_finish();
            return 0;
        }
        argument = vpi_scan(iterator);
    }

    if (i != CPU::pliCore->busCount) {
        printf("Error: Invalid argument count. (%i/%zu)\n", i, CPU::pliCore->busCount);
        vpi_finish();
    }

    return 0;
}

int32_t update_calltf(char* user_data) {
    CPU::pliCore->cycleCounter += 1;
    onDebug(std::cout << "CPU Update for Cycle " <<  CPU::pliCore->cycleCounter << std::endl);     
    if (CPU::pliCore->status == CPU::STATUS_IDLE) {
        return 0;
    }
    
    std::vector<vpiHandle> buses(CPU::pliCore->busCount);
    
    auto handle = vpi_handle(vpiSysTfCall, NULL);

    auto iterator = vpi_iterate(vpiArgument, handle);

    t_vpi_value value;
    value.format = vpiIntVal;
    
    for (int i = 0; i < CPU::pliCore->busCount; i++) {
        buses[i] = vpi_scan(iterator);
        vpi_get_value(buses[i], &value);
        CPU::pliCore->buses[i] = value.value.integer;
    }
    
    CPU::pliCore->update();

    auto & events = CPU::pliCore->cpuBusEvents;

    while (!events.empty() && events.top().cycle == CPU::pliCore->cycleCounter) {
        CPU::pliCore->buses[events.top().bus] = events.top().value;
        events.pop();
    }

    for (size_t i = 0; i < CPU::pliCore->busCount; i += 1) {
        if (CPU::pliCore->masterControlled[i]) {
            value.value.integer = CPU::pliCore->buses[i];
            vpi_put_value(buses[i], &value, NULL, vpiNoDelay);
        }
    }

    return 0;
}

int32_t memoryUpdate_compiletf(char* user_data) {
    auto handle = vpi_handle(vpiSysTfCall, NULL);
    if (handle == NULL) {
        printf("Fatal Error: Failed to obtain handle. The simulation will abort.\n");
        vpi_finish();
        return 0;
    }

    auto iterator = vpi_iterate(vpiArgument, handle);
    if (iterator == NULL) {
        printf("Error: No arguments.\n");
        vpi_finish();
        return 0;
    }

    int i = 0;
    auto argument = vpi_scan(iterator);

    while (argument) {
        i += 1;
        auto type = vpi_get(vpiType, argument);

        if (type != vpiNet && type != vpiReg) {
            printf("Error: Argument %i: invalid argument.\n", i);
            vpi_finish();
            return 0;
        }
        argument = vpi_scan(iterator);
    }

    if (i != CPU::pliCore->busCount)  {
        printf("Error: Invalid argument count. (%i/%zu)\n", i, CPU::pliCore->busCount);
        vpi_finish();
    }

    return 0;
}

int32_t memoryUpdate_calltf(char* user_data) {  
    
    onDebug(std::cout << "Memory Update for Cycle " <<  CPU::pliCore->cycleCounter << std::endl);  
    if (CPU::pliCore->status == CPU::STATUS_IDLE) {
        return 0;
    }

    auto handle = vpi_handle(vpiSysTfCall, NULL);

    auto iterator = vpi_iterate(vpiArgument, handle);

    t_vpi_value value;
    value.format = vpiIntVal;

    std::vector<vpiHandle> buses(CPU::pliCore->busCount);

    for (int i = 0; i < CPU::pliCore->busCount; i++) {
        buses[i] = vpi_scan(iterator);
    }

    while (!CPU::pliCore->memoryBusEvents.empty() && CPU::pliCore->memoryBusEvents.top().cycle == CPU::pliCore->cycleCounter) {
        value.value.integer = CPU::pliCore->memoryBusEvents.top().value;
        vpi_put_value(buses[CPU::pliCore->memoryBusEvents.top().bus], &value, NULL, vpiNoDelay);
        CPU::pliCore->memoryBusEvents.pop();
    }

     if (!CPU::pliCore->memoryBusEvents.empty() && CPU::pliCore->memoryBusEvents.top().cycle < CPU::pliCore->cycleCounter) {
         std::cerr << "Fatal error: Memory event at cycle " << CPU::pliCore->memoryBusEvents.top().cycle << " not executed for bus "  << CPU::pliCore->cpuBusEvents.top().bus << " (Cycle " << CPU::pliCore->cycleCounter << " reached.)" << std::endl;
     }

    return 0;
}


extern "C" void initialize() {
    auto soc = IO::soc();
    JSON *ramObject = NULL;
    std::string cpuName;
    bool cpuFound = false;
    
    
    for (JSON::iterator it = soc["ips"].begin(); it != soc["ips"].end(); it++) {
        auto & element = *it;

        if (element["bfm"] == "__Beekeeper_InstantRAM") {
            if (ramObject) {
                std::cerr << "Only one BFM RAM module supported." << std::endl;
                exit(65);
            }
            ramObject = &element;            
        } else if (element["bfm"] != nullptr) {
            if (CPU::database.find(element["bfm"]) != CPU::database.end())
            {
                if (cpuFound) {
                    std::cerr << "Only one BFM CPU supported." << std::endl;
                    exit(65);
                }
                cpuName = element["bfm"];
                cpuFound = true;
            } else {
                std::cerr << "Unknown bus functional model " << element["bfm"] << std::endl;
                exit(65);
            }
        }
    }

    if (!cpuFound) {
        std::cerr << "No CPU specified." << std::endl;
        exit(65);
    }

    CPU::pliCore = CPU::database[cpuName](ramObject);

    s_vpi_systf_data* initialize = new s_vpi_systf_data();
    initialize->type = vpiSysTask;
    initialize->tfname = "$bk_initialize";
    initialize->calltf  = initialize_calltf;
    initialize->compiletf = initialize_compiletf;
    initialize->sizetf = NULL;
    initialize->user_data = NULL;
    vpi_register_systf(initialize);

    s_vpi_systf_data* update = new s_vpi_systf_data();
    update->type = vpiSysTask;
    update->tfname = "$bk_update";
    update->calltf  = update_calltf;
    update->compiletf = update_compiletf;
    update->sizetf = NULL;
    update->user_data = NULL;
    vpi_register_systf(update);

    s_vpi_systf_data* memoryUpdate = new s_vpi_systf_data();
    update->type = vpiSysTask;
    update->tfname = "$bk_memoryUpdate";
    update->calltf  = memoryUpdate_calltf;
    update->compiletf = memoryUpdate_compiletf;
    update->sizetf = NULL;
    update->user_data = NULL;
    vpi_register_systf(update);    
}

extern "C" void (*vlog_startup_routines[])() = {
    initialize,
    NULL
};

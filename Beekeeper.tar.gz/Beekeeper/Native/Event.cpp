#include "Event.h"

bool operator<(const Event& left, const Event& right) {
    return left.cycle > right.cycle;
}

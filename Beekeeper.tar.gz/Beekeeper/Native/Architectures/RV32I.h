#pragma once

//Project Headers
#include "../Common.h"

const uint8 STACK_POINTER = 2;
const uint8 RA_ADDRESS = 1;

extern uint8 zeroInst[32];

extern uint8 OPCODE_LUI[7];
extern uint8 OPCODE_AUIPC[7];
extern uint8 OPCODE_JAL[7];
extern uint8 OPCODE_JALR[7];
extern uint8 OPCODE_BRANCH[7];
extern uint8 OPCODE_LOAD[7];
extern uint8 OPCODE_SAVE[7];
extern uint8 OPCODE_ALUI[7];
extern uint8 OPCODE_ALUR[7];
extern uint8 OPCODE_FENCE[7];
extern uint8 OPCODE_ECALL[7];

extern uint8 FUNCT3_000[3];
extern uint8 FUNCT3_001[3];
extern uint8 FUNCT3_010[3];
extern uint8 FUNCT3_011[3];
extern uint8 FUNCT3_100[3];
extern uint8 FUNCT3_101[3];
extern uint8 FUNCT3_110[3];
extern uint8 FUNCT3_111[3];

extern uint8 BITON[1];
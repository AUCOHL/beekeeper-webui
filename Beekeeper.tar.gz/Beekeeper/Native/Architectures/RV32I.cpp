#include "RV32I.h"

uint8 OPCODE_LUI[7]     = {1,1,1,0,1,1,0};
uint8 OPCODE_AUIPC[7]   = {1,1,1,0,1,0,0};
uint8 OPCODE_JAL[7]     = {1,1,1,1,0,1,1};
uint8 OPCODE_JALR[7]    = {1,1,1,0,0,1,1};
uint8 OPCODE_BRANCH[7]  = {1,1,0,0,0,1,1};
uint8 OPCODE_LOAD[7]    = {1,1,0,0,0,0,0};
uint8 OPCODE_SAVE[7]    = {1,1,0,0,0,1,0};
uint8 OPCODE_ALUI[7]    = {1,1,0,0,1,0,0};
uint8 OPCODE_ALUR[7]    = {1,1,0,0,1,1,0};
uint8 OPCODE_FENCE[7]   = {1,1,1,1,0,0,0};
uint8 OPCODE_ECALL[7]   = {1,1,0,0,1,1,1};

uint8 FUNCT3_000[3] = {0,0,0};
uint8 FUNCT3_001[3] = {1,0,0};
uint8 FUNCT3_010[3] = {0,1,0};
uint8 FUNCT3_011[3] = {1,1,0};
uint8 FUNCT3_100[3] = {0,0,1};
uint8 FUNCT3_101[3] = {1,0,1};
uint8 FUNCT3_110[3] = {0,1,1};
uint8 FUNCT3_111[3] = {1,1,1};

uint8 BITON[1] = {1};
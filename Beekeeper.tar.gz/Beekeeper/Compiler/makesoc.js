#!/usr/bin/env node
//This script compiles a RISC-V Mixed C/Assembly program. Complies with BSD exit codes.
const exec = require('child_process').exec;
const path = require('path');
    
//Getting SoC
exec(`cat Compiler/examplesoc.json`, (error, stdout, stderr) => {
if (error || stderr) {
    console.error(`File reading failed: ${error}.`);
    process.exit(73);
}
var soc = eval(stdout)[0]; //Don't ask. I don't get this either.
var bus = soc.bus;
var memoryMap = soc.ips;

//Compiling Testbench
exec(`cat Compiler/${bus}/SLAVE_TEMPLATE.js`, (error, stdout, stderr) => {
if (error || stderr) {
    console.error(`File reading failed: ${error}.`);
    process.exit(73);
}
var slaveTemplate = stdout;

exec(`cat Compiler/${bus}/MASTER_TEMPLATE.js`, (error, stdout, stderr) => {
if (error || stderr) {
    console.error(`File reading failed: ${error}.`);
    process.exit(73);
}
var masterTemplate = stdout;

exec(`cat Compiler/${bus}/MEMORYMAP_TEMPLATE.js`, (error, stdout, stderr) => {
if (error || stderr) {
    console.error(`File reading failed: ${error}.`);
    process.exit(73);
}
var memoryMapTemplate = stdout;

exec(`cat Compiler/${bus}/MEMORYMAPREG_TEMPLATE.js`, (error, stdout, stderr) => {
if (error || stderr) {
    console.error(`File reading failed: ${error}.`);
    process.exit(73);
}
var memoryMapRegTemplate = stdout;

var beekeeper_header = [`/*
* Cloud V SoC Generator
* Generated on ${new Date().toString()}.
*/

// Note: Ends are exclusive.
`
];

var includes = [];

var memoryMapRegs = [];
var memoryMaps = [];

var modules = [];

for (var i = 0; i < memoryMap.length; i++) {
    var id = memoryMap[i].id;
    var start = memoryMap[i].start;
    var length = memoryMap[i].length;
    var end = start + length;
    var flag = (start != null);
    includes[memoryMap[i].verilog] = 1;
    modules.push(`${memoryMap[i].verilog} ${id} ${eval(flag? slaveTemplate: masterTemplate)};`);
    if (flag) {
        memoryMapRegs.push(eval(memoryMapRegTemplate));
        memoryMaps.push(eval(memoryMapTemplate));
        beekeeper_header.push(`#define BEEKEEPER_MEMORY_${id}_START ${start}`);
        beekeeper_header.push(`#define BEEKEEPER_MEMORY_${id}_LENGTH ${length}`);
        beekeeper_header.push(`#define BEEKEEPER_MEMORY_${id}_END ${end}`);
        beekeeper_header.push(``);
    }
}

var beekeeper_includes = "";
for (key in includes) { beekeeper_includes += `\`include "Verilog/${key}.v"\n`; }
var beekeeper_memorymapregs = memoryMapRegs.join("\n");
var beekeeper_memorymaps = memoryMaps.join("\n\n");
var beekeeper_modules = modules.join("\n\n");

exec(`cat Compiler/${bus}/VERILOG_TEMPLATE.js`, (error, stdout, stderr) => {
if (error || stderr) {
    console.error(`File reading failed: ${error}.`);
    process.exit(73);
}

exec(`echo '${eval(stdout)}' > Generated.v`, (error, stdout, stderr) => {
if (error || stderr) {
    console.error(`File creation failed: ${error}.`);
    process.exit(73);
}

exec(`echo '${beekeeper_header.join("\n")}' > Compiler/include/CloudV/Beekeeper.h`, (error, stdout, stderr) => {
if (error || stderr) {
    console.error(`File creation failed: ${error}.`);
    process.exit(73);
}

});
});
});
});
});
});
});
});
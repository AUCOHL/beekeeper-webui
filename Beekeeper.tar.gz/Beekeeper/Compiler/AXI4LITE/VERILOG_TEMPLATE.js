`
/*
 * Cloud V SoC Generator
 * Generated on ${new Date().toString()}.
 */


\`timescale 1ps/1ps

${beekeeper_includes}

module Bus;

reg clk, rst;

localparam width = 32;
localparam bytes = 4;

wire AWVALID;
wire AWREADY;
wire [width - 1: 0] AWADDR;
wire [2: 0] AWPROT;

//Write Data
wire WVALID;
wire WREADY;
wire [width - 1: 0] WDATA;
wire [bytes - 1: 0] WSTRB;

//Write Response
wire BVALID;
wire BREADY;
wire [1: 0] BRESP;

//Read Address Channel
wire ARVALID;
wire ARREADY;
wire [width - 1: 0] ARADDR;
wire [2: 0] ARPROT;

//Read Data Channel
wire RVALID;
wire RREADY;
wire [width - 1: 0] RDATA;
wire [1: 0] RRESP;

always begin
    #1 clk = !clk;
end

${beekeeper_memorymapregs}

always @(*) begin

${beekeeper_memorymaps}

end

${beekeeper_modules}

initial
begin
    clk = 0;
    rst = 1;
    $dumpvars(0, Bus);
    $dumpflush;
    #50;
    rst = 0;
    // Your code here 
end

endmodule
`
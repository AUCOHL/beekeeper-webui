extern void example();

int main()
{
    example();
    return 0;
}
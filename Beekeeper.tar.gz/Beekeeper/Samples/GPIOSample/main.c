#include <CloudV/Beekeeper.h>

extern void example();

int main()
{
    example();
    return 0;
}
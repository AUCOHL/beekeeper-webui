void function()
{
    int a = 42;
    return;
}
#!/bin/bash
unamestr=`uname`

# macOS using Mach-style binaries means leaving some symbols hanging like that isn't viable without a special option.
if [ $unamestr = "Darwin" ]; then
    echo "Compiling for macOS."
    clang++ -fPIC -shared -std=c++11 -undefined dynamic_lookup -I/usr/local/include/ Native/*.cpp -O0 -g -o Beekeeper.vpi
else
    echo "Compiling for Linux."        
    clang++ -fPIC -shared -std=c++11 Native/*.cpp -O0 -g -o Beekeeper.vpi 
fi
iverilog -o Beekeeper.vvp Generated.v

#!/bin/bash
unamestr=`uname`

# macOS using Mach-style binaries means leaving some symbols hanging like that isn't viable without a special option.
if [ $unamestr = "Darwin" ]; then
    echo "Compiling for macOS."
    clang++ -std=c++11 -I/usr/local/include/ -D_bk_standalone Native/*.cpp -O3 -o Beekeeper.mach
else
    echo "Compiling for Linux."        
    clang++ -std=c++11 -D_bk_standalone Native/*.cpp -O3 -o Beekeeper.elf
fi
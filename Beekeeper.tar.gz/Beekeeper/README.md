# BeeKeeper
A research project on hardware/software coverification using the Verilog Procedural Interface as part of [Cloud V](http://cloudv.io).

Unlike [Oak.js's simulator](https://github.com/skyus/Oak.js), where extensibility/hackability was the architectural design focus, BeeKeeper's simulation module is hardwired for RV32i with an emphasis on performance and bus-cycle-accuracy.

The verilog module is designed after the AMBA AXI4-Lite specification.

# Dependencies

* Unix or Unix-like operating system: We're testing both Apple macOS and GNU/Linux.

* Node.js: Generally whatever version your package manager provides should be fine. You will also need the module 'node-getopt' for the bkcc script.

* A valid full-coverage ISO C++14 compiler is required. We recommend Clang as it is generally in-date regardless of your Linux distribution's status.

* The RISC-V GNU Toolchain, pre-compiled by SiFive. You can find them at the bottom of this page: https://www.sifive.com/products/tools/


## Installing
### macOS
You will need Xcode and will probably want to use [Homebrew](https://github.com/Homebrew/homebrew/blob/master/share/doc/homebrew/Installation.md).

```bash
    brew install node icarus-verilog
```

### GNU/Linux
You will need nodejs symlinked to node, as well as IcarusVerilog and Clang as previously mentioned.

Here are the instructions on Debian-based OSes:

```bash
    sudo apt install nodejs iverilog clang
    sudo ln -s /usr/bin/nodejs /usr/bin/node
```

### General
Installing the node module:

```bash
    sudo npm install node-getopt # sudo not required on macOS
```

To install the GNU toolchain, download the package from SiFive relevant to your OS and add it to your path. Please note again that Windows backends are not supported.

# Usage
## Compiling the VPI module
You can write `make` or `make release` in the terminal. The VPI module will be generated.

## Compiling the program to simulate
In the terminal, `./bkcc [C and Assembly Files]`. A folder will be generated with the resultant files.

Currently, only the folder name `Beekeeper.bin_dump` is supported and it must be in the same folder vvp is invoked.

## Generate the SoC helper files
You can write `make soc` to recompile the soc files. This generates a testbench called `Generated.v` for you to customize.

## Compiling the VVP
Assuming you generated the SoC helper files at least once:

`iverilog -o Beekeeper.vvp Generated.v`

## Running
`./beekeeper` to run. You may optionally select a file that is not `Beekeeper.bin` by adding its name as an argument.

Remember, by now these three files should exist: `Beekeeper.bin`, `Beekeeper.vpi` and `Beekeeper.vvp`. These are the three you need for a simulation.

### With Xcode
The included Xcode project lets you use breakpoints and stuff normally.

## Standalone Simulation App
The standalone simulation app is no longer supported.

# Licensing Note
The code links against the Verilog Procedural Interface for IcarusVerilog and thus has to be redistributed under the GNU General Public License v2 or later should it ever be distributed. We may elect to release it as GPL software or keep it.